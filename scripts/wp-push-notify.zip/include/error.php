<div class="error notice">
    <p>There has been an error on notification send.</p>
</div>
