<input type="checkbox" id="wppn_send_on_update" <?php if ($this->sendOnUpdate) echo 'checked' ?> name="wppn_send_on_update">
<label for="wppn_send_on_update">Send notification on post update</label>